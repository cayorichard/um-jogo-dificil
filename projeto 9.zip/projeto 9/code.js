var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var vidas = 0;
var borda1 = createSprite(190, 120,420,3);
var borda2 = createSprite(190, 260,420,3);
var sam = createSprite(20, 190,13,13);
var carro1 = createSprite(215, 130,20,20);
var carro2 = createSprite(100, 130,20,20);
var carro3 = createSprite(165, 250,20,20);
var carro4 = createSprite(270, 250,20,20);
sam.shapeColor ='green';
carro1.shapeColor ='red';
carro2.shapeColor ='red';
carro3.shapeColor ='red';
carro4.shapeColor ='red';
carro1.velocityY =-2;
carro2.velocityY =+2;
carro3.velocityY =-2;
carro4.velocityY =+2;
createEdgeSprites()
sam.bounce(rightEdge);


function draw()
 background("white");
  textSize(20);
text("vidas :"+ vidas,200, 100);
 
  fill("yellow");
  rect(0, 120, 52, 140);
  fill("blue");
  rect(345, 120, 52, 140);
  drawSprites();
 carro1.bounceOff(borda1);
 carro1.bounceOff(borda2);
 carro2.bounceOff(borda1);
 carro2.bounceOff(borda2);
carro3.bounceOff(borda1);
carro3.bounceOff(borda2);
carro4.bounceOff(borda1);
carro4.bounceOff(borda2);

if (keyDown("RIGHT_ARROW")) {
  sam.velocityX = sam.velocityX =+2
  
}
if (keyDown("LEFT_ARROW")) {
  sam.velocityX = sam.velocityX =-2
  
  
}
if (sam.isTouching(carro1)) {
  sam.setVelocity(0, 0)
  sam.x =20
  
}
if (sam.isTouching(carro2)) {
  sam.setVelocity(0, 0)
  sam.x =20
  
}
if (sam.isTouching(carro3)) {
  sam.setVelocity(0, 0)
  sam.x =20
  
}
if (sam.isTouching(carro4)) {
  sam.setVelocity(0, 0)
  sam.x =20
  
}

}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
